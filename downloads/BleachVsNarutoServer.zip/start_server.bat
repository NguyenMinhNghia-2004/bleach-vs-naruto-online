@echo off
title BLEACH VS NARUTO - ONLINE RELAY SERVER
cd /d "%~dp0"
if not exist "cloudflared.exe" (
    echo Dang tai cloudflared.exe ...
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile 'cloudflared.exe'"
)
start "BVN Relay Server (TCP 7777 & WS 7778)" "BleachVsNarutoServer.exe" 7777
timeout /t 2 /nobreak >nul
start "Cloudflare Public Tunnel" "cloudflared.exe" tunnel --url http://127.0.0.1:7778
echo.
echo May chu da chay: TCP 7777 (ban PC) va WebSocket 7778 (ban Web).
echo Tim dong https://xxx.trycloudflare.com trong cua so Cloudflare, roi gui ban be link:
echo   https://nguyenminhnghia-2004.github.io/bleach-vs-naruto-online/?server=xxx.trycloudflare.com
echo Moi lan chay lai, dia chi tunnel se doi - nho gui link moi.
pause
